(() => {
  const $ = (id) => document.getElementById(id);
  const video = $("sourceVideo"), canvas = $("previewCanvas"), ctx = canvas.getContext("2d");
  const fileInput = $("videoFile"), startInput = $("startTime"), endInput = $("endTime");
  const exportBtn = $("exportBtn"), playBtn = $("playBtn"), previewBtn = $("previewBtn");
  const captionInput = $("captionText"), captionStyle = $("captionStyle");
  let objectUrl = null, selectedRatio = "9:16", duration = 0, raf = null, previewing = false, recorder = null, chunks = [], exportUrl = null;
  const dimensions = {"9:16":[360,640],"1:1":[540,540],"16:9":[640,360]};
  const fmt = (seconds, tenths=false) => {
    seconds = Math.max(0, Number(seconds) || 0);
    const m = Math.floor(seconds/60), s = seconds%60;
    return `${m}:${tenths ? s.toFixed(1).padStart(4,"0") : String(Math.floor(s)).padStart(2,"0")}`;
  };
  const selectedStart = () => Number(startInput.value) || 0;
  const selectedEnd = () => Number(endInput.value) || 0;
  function setStatus(message, show=true) { $("exportStatus").textContent = message; $("exportStatus").classList.toggle("hidden", !show); }
  function setRatio(ratio) {
    selectedRatio = ratio;
    const [w,h] = dimensions[ratio]; canvas.width=w; canvas.height=h;
    $("previewFrame").style.aspectRatio = `${w}/${h}`;
    $("previewRatio").textContent = ratio;
    document.querySelectorAll(".ratio").forEach(b=>b.classList.toggle("active",b.dataset.ratio===ratio));
    drawFrame();
  }
  function drawFrame() {
    const w=canvas.width,h=canvas.height;
    ctx.fillStyle="#101014";ctx.fillRect(0,0,w,h);
    if (video.readyState >= 2 && video.videoWidth) {
      const scale=Math.max(w/video.videoWidth,h/video.videoHeight);
      const sw=w/scale, sh=h/scale;
      const sx=(video.videoWidth-sw)/2, sy=(video.videoHeight-sh)/2;
      ctx.drawImage(video,sx,sy,sw,sh,0,0,w,h);
      const caption=captionInput.value.trim();
      if(caption){
        const maxWidth=w*.84, fontSize=Math.max(18,Math.round(w*.062));
        ctx.font=`800 ${fontSize}px Arial, sans-serif`;
        const words=caption.split(/\s+/), lines=[]; let line="";
        for(const word of words){const test=line?line+" "+word:word;if(ctx.measureText(test).width>maxWidth && line){lines.push(line);line=word}else line=test}
        if(line)lines.push(line);
        const lineHeight=fontSize*1.18, blockH=lines.length*lineHeight, y=h*.78-blockH/2;
        ctx.textAlign="center";ctx.textBaseline="middle";
        if(captionStyle.value==="box"){
          const maxLine=Math.max(...lines.map(t=>ctx.measureText(t).width));
          ctx.fillStyle="rgba(0,0,0,.72)";ctx.fillRect((w-maxLine)/2-12,y-lineHeight/2-8,maxLine+24,blockH+16);
        }
        lines.forEach((t,i)=>{
          const yy=y+i*lineHeight;
          if(captionStyle.value==="bold"){ctx.lineWidth=Math.max(3,fontSize*.18);ctx.strokeStyle="#111";ctx.strokeText(t,w/2,yy)}
          ctx.fillStyle="#fff";ctx.fillText(t,w/2,yy);
        });
      }
    }
    $("emptyPreview").classList.toggle("hidden",!!(video.src && video.readyState>=2));
    $("playTime").textContent=fmt(video.currentTime,true);
    const total=Math.max(0,selectedEnd()-selectedStart());
    $("clipDuration").textContent=fmt(total);
    $("clipLength").textContent=`${total.toFixed(1)} seconds selected`;
    const left=duration?selectedStart()/duration*100:0, width=duration?total/duration*100:100;
    $("timelineSelection").style.left=left+"%";$("timelineSelection").style.width=Math.max(0,width)+"%";
  }
  function stopAnimation(){if(raf)cancelAnimationFrame(raf);raf=null}
  function animate(){drawFrame();if(!video.paused&&!video.ended)raf=requestAnimationFrame(animate)}
  function syncTime(){drawFrame();if(video.currentTime>=selectedEnd()-.03 && previewing){video.pause();previewing=false;playBtn.textContent="▶";video.currentTime=selectedStart();drawFrame()}}
  function loadVideo(file){
    if(!file)return;
    if(!file.type.startsWith("video/")){setStatus("Please select a video file.");return}
    if(file.size>500*1024*1024){setStatus("This file is over 500 MB. Try a smaller file for smoother browser editing.");return}
    if(objectUrl)URL.revokeObjectURL(objectUrl);
    objectUrl=URL.createObjectURL(file);video.src=objectUrl;video.load();
    $("fileInfo").textContent=`${file.name} · ${(file.size/1024/1024).toFixed(1)} MB`;
    $("fileInfo").classList.remove("hidden");$("downloadLink").classList.add("hidden");setStatus("",false);
  }
  fileInput.addEventListener("change",e=>loadVideo(e.target.files[0]));
  const dropzone=$("dropzone");
  ["dragenter","dragover"].forEach(ev=>dropzone.addEventListener(ev,e=>{e.preventDefault();dropzone.classList.add("dragover")}));
  ["dragleave","drop"].forEach(ev=>dropzone.addEventListener(ev,e=>{e.preventDefault();dropzone.classList.remove("dragover")}));
  dropzone.addEventListener("drop",e=>loadVideo(e.dataTransfer.files[0]));
  video.addEventListener("loadedmetadata",()=>{
    duration=video.duration;
    if(!Number.isFinite(duration)||duration<=0){setStatus("This video format could not be read by your browser.");return}
    startInput.max=duration;endInput.max=duration;startInput.step=endInput.step=.1;
    startInput.value=0;endInput.value=duration;
    startInput.disabled=endInput.disabled=false;playBtn.disabled=previewBtn.disabled=exportBtn.disabled=false;
    $("durationLabel").textContent=fmt(duration);$("timelineTotal").textContent=fmt(duration);
    video.currentTime=0;drawFrame();
  });
  video.addEventListener("seeked",drawFrame);
  video.addEventListener("timeupdate",syncTime);
  video.addEventListener("play",()=>{stopAnimation();animate()});
  video.addEventListener("pause",()=>{stopAnimation();drawFrame()});
  [startInput,endInput].forEach(input=>input.addEventListener("input",()=>{
    let s=selectedStart(),e=selectedEnd();
    if(input===startInput&&s>=e){e=Math.min(duration,s+.1);endInput.value=e}
    if(input===endInput&&e<=s){s=Math.max(0,e-.1);startInput.value=s}
    $("startLabel").textContent=fmt(selectedStart(),true);$("endLabel").textContent=fmt(selectedEnd(),true);
    if(video.currentTime<selectedStart()||video.currentTime>selectedEnd())video.currentTime=selectedStart();
    drawFrame();
  }));
  document.querySelectorAll(".ratio").forEach(b=>b.addEventListener("click",()=>setRatio(b.dataset.ratio)));
  [captionInput,captionStyle].forEach(el=>el.addEventListener("input",drawFrame));
  playBtn.addEventListener("click",()=>{
    if(video.paused){if(video.currentTime<selectedStart()||video.currentTime>=selectedEnd())video.currentTime=selectedStart();previewing=true;video.play().then(()=>playBtn.textContent="Ⅱ").catch(()=>setStatus("Your browser could not play this video."))}
    else{previewing=false;video.pause();playBtn.textContent="▶"}
  });
  previewBtn.addEventListener("click",()=>{
    previewing=true;video.currentTime=selectedStart();video.play().then(()=>playBtn.textContent="Ⅱ").catch(()=>setStatus("Could not play preview."));
  });
  video.addEventListener("pause",()=>{if(!previewing)playBtn.textContent="▶"});
  exportBtn.addEventListener("click",async()=>{
    const start=selectedStart(),end=selectedEnd();
    if(!video.src||end<=start){setStatus("Choose a valid clip range first.");return}
    if(!("MediaRecorder" in window)||!canvas.captureStream){setStatus("Export needs a recent Chrome, Edge, or Firefox browser. Try opening this site in Chrome.");return}
    if(exportUrl){URL.revokeObjectURL(exportUrl);exportUrl=null}
    $("downloadLink").classList.add("hidden");exportBtn.disabled=true;exportBtn.textContent="Exporting…";
    setStatus("Preparing export. The video will play through the selected range in real time. Keep this tab open.");
    try{
      video.pause();video.currentTime=start;
      await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(new Error("Video seek timed out. Try again.")),10000);if(Math.abs(video.currentTime-start)<.04&&video.readyState>=2){clearTimeout(timeout);resolve()}else{video.addEventListener("seeked",function onSeek(){clearTimeout(timeout);video.removeEventListener("seeked",onSeek);resolve()},{once:true})}});
      drawFrame();
      const canvasStream=canvas.captureStream(30);
      let stream=canvasStream;
      try{
        if(video.captureStream){const sourceStream=video.captureStream();sourceStream.getAudioTracks().forEach(t=>canvasStream.addTrack(t))}
      }catch(_){}
      const mimeTypes=["video/webm;codecs=vp9,opus","video/webm;codecs=vp8,opus","video/webm"];
      const mimeType=mimeTypes.find(t=>MediaRecorder.isTypeSupported(t))||"";
      recorder=new MediaRecorder(stream,mimeType?{mimeType}:undefined);chunks=[];
      recorder.ondataavailable=e=>{if(e.data&&e.data.size)chunks.push(e.data)};
      recorder.onerror=()=>{setStatus("Export failed in this browser. Try Chrome on desktop with a smaller video.");finishExportButton()};
      recorder.onstop=()=>{
        const blob=new Blob(chunks,{type:recorder.mimeType||"video/webm"});
        exportUrl=URL.createObjectURL(blob);const link=$("downloadLink");
        link.href=exportUrl;link.download=`clipforge-${Date.now()}.webm`;link.classList.remove("hidden");
        setStatus(`Export ready · ${(blob.size/1024/1024).toFixed(1)} MB · WebM video. Preview it before posting.`);
        stream.getTracks().forEach(t=>t.stop());video.pause();video.currentTime=start;previewing=false;drawFrame();finishExportButton();
      };
      recorder.start(250);
      video.currentTime=start;
      await video.play();
      const durationMs=(end-start)*1000;
      const startedAt=performance.now();
      const monitor=()=>{
        if(!recorder||recorder.state!=="recording")return;
        const elapsed=performance.now()-startedAt;
        setStatus(`Exporting in real time… ${Math.min(100,Math.round(elapsed/durationMs*100))}%`);
        if(elapsed>=durationMs||video.currentTime>=end-.04){video.pause();if(recorder.state==="recording")recorder.stop();return}
        requestAnimationFrame(monitor);
      };
      requestAnimationFrame(monitor);
    }catch(err){setStatus(`Could not export: ${err.message||"browser error"}. Try Chrome, a shorter clip, or a smaller file.`);finishExportButton()}
  });
  function finishExportButton(){exportBtn.disabled=false;exportBtn.innerHTML='Export clip <span>↗</span>'}

  // Transcript-based highlight suggestions. This is transparent heuristic scoring,
  // not an LLM or speech-recognition system.
  const findBtn = $("findHighlightsBtn");
  if (findBtn) findBtn.addEventListener("click", () => {
    const raw = $("transcriptInput").value.trim();
    const goal = $("clipPrompt").value.trim();
    if (!raw) { setStatus("Paste a transcript first to generate highlight suggestions."); return; }
    const paragraphs = raw.split(/\n\s*\n/).map(s=>s.trim()).filter(Boolean);
    const segments = paragraphs.length > 1 ? paragraphs : raw.split(/(?<=[.!?])\s+(?=[A-Z0-9“"'])/).map(s=>s.trim()).filter(Boolean);
    const totalDuration = duration || Math.max(segments.length * 12, 60);
    const timestampRegex = /\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/;
    const positive = ["secret","mistake","never","best","worst","why","how","truth","surprising","shocking","important","learn","money","free","fast","result","problem","solution","because","actually","imagine","wrong","right","change","first","only","everyone","nobody","fail","success","tip","trick","lesson","लेकिन","क्यों","कैसे","सच","गलती","पैसा","मुफ्त","सीखो","जरूरी","सबसे","ध्यान","समस्या","समाधान","कमाई"];
    const target = goal.toLowerCase();
    const results = segments.map((text,i)=>{
      const words=text.split(/\s+/).filter(Boolean), lower=text.toLowerCase();
      let score=42;
      score += Math.min(18, Math.max(0, words.length-5)*0.45);
      score += Math.min(15, (text.match(/[?!]/g)||[]).length*5);
      score += Math.min(25, positive.reduce((n,w)=>n+(lower.includes(w)?1:0),0)*5);
      if(/\d/.test(text)) score+=5;
      if(words.length<5) score-=12;
      if(words.length>75) score-=10;
      if(target){const terms=target.split(/\W+/).filter(w=>w.length>3);const hits=terms.filter(w=>lower.includes(w)).length;score+=Math.min(12,hits*4)}
      score=Math.max(25,Math.min(98,Math.round(score)));
      let start=i*totalDuration/segments.length, end=(i+1)*totalDuration/segments.length;
      const match=text.match(timestampRegex);
      if(match){
        const nums=match.slice(1).filter(Boolean).map(Number);
        const sec=nums.length===3?nums[0]*3600+nums[1]*60+nums[2]:nums[0]*60+nums[1];
        start=Math.max(0,sec);end=Math.min(totalDuration,start+Math.max(15,Math.min(45,words.length/2)));
      }
      const clean=text.replace(timestampRegex,"").replace(/\s+/g," ").trim();
      const title=clean.length>64?clean.slice(0,61).replace(/\s+\S*$/,"")+"…":clean;
      return {text:clean,title:title||`Highlight ${i+1}`,score,start:Math.min(start,Math.max(0,totalDuration-1)),end:Math.min(totalDuration,Math.max(start+1,end)),index:i};
    }).sort((a,b)=>b.score-a.score).slice(0,Math.min(9,segments.length));
    const holder=$("highlightCards");holder.innerHTML="";
    results.forEach((item,idx)=>{
      const card=document.createElement("article");card.className="highlight-card";
      const top=document.createElement("div");top.className="clip-card-top";
      const score=document.createElement("span");score.className="score";score.textContent=`Score ${item.score}`;
      const time=document.createElement("span");time.className="clip-time";time.textContent=`${fmt(item.start)} – ${fmt(item.end)}`;
      top.append(score,time);
      const title=document.createElement("h4");title.textContent=item.title;
      const desc=document.createElement("p");desc.textContent=item.text.length>110?item.text.slice(0,107)+"…":item.text;
      const btn=document.createElement("button");btn.textContent="Use this clip";
      btn.addEventListener("click",()=>{
        document.querySelectorAll(".highlight-card").forEach(c=>c.classList.remove("selected"));card.classList.add("selected");
        if(duration>0){
          const s=Math.max(0,Math.min(duration-.2,item.start)),e=Math.max(s+.1,Math.min(duration,item.end));
          startInput.value=s;endInput.value=e;
          $("startLabel").textContent=fmt(s,true);$("endLabel").textContent=fmt(e,true);
          video.currentTime=s;drawFrame();
        }
        captionInput.value=item.title;
        drawFrame();
        if(!duration)setStatus("Suggestion selected. Upload a video to apply the suggested time range and export.");
        else setStatus(`Selected suggestion (heuristic score ${item.score}/100). Review the cut before exporting.`);
        $("editor").scrollIntoView({behavior:"smooth",block:"start"});
      });
      card.append(top,title,desc,btn);holder.appendChild(card);
    });
    $("resultCount").textContent=`${results.length} suggestion${results.length===1?"":"s"} · heuristic scores, not guaranteed virality`;
    $("highlightResults").classList.remove("hidden");
    setStatus(`Generated ${results.length} transcript-based suggestions. Scores are heuristic estimates, not predictions of actual views.`);
  });

  setRatio("9:16");drawFrame();
})();